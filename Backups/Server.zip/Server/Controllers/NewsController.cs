﻿using Microsoft.AspNetCore.Mvc;
using Server.BL;


namespace Server.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class NewsController : ControllerBase
    {
        [HttpPost("save")]
        public IActionResult SaveNews([FromBody] SaveNewsRequest request, [FromQuery] int userId)
        {
            try
            {
                var article = new News
                {
                    Title = request.Title ?? "",
                    Content = request.Content ?? "",
                    Url = request.Url ?? "",
                    UrlToImage = request.UrlToImage,
                    PublishedAt = request.PublishedAt ?? DateTime.UtcNow,
                    Source = request.Source,
                    Author = request.Author,
                    Category = request.Category ?? "general",
                    Sentiment = request.Sentiment,
                    Country = request.Country
                };

                int id = News.SaveNews(article, userId);
                return Ok(new { newsId = id });
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Error: " + ex.Message);
            }
        }


        [HttpGet("saved")]
        public IActionResult GetSavedNewsForUser([FromQuery] int userId)
        {
            try
            {
                var savedArticles = News.GetSavedNews(userId);
                return Ok(new
                {
                    articles = savedArticles,
                    message = $"Found {savedArticles.Count} saved articles",
                    count = savedArticles.Count
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    error = "DB failure",
                    message = ex.Message
                });
            }
        }


        [HttpGet("saved/{newsId}")]
        public IActionResult GetSavedNewsById(int newsId, [FromQuery] int userId)
        {
            try
            {
                var article = News.GetSavedNewsById(newsId, userId);
                return article == null ? NotFound() : Ok(article);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Error: " + ex.Message);
            }
        }


        [HttpDelete("saved/{newsId}")]
        public IActionResult UnsaveNewsForUser(int newsId, [FromQuery] int userId)
        {
            try
            {
                bool result = News.UnsaveForUser(userId, newsId);

                return result
                    ? Ok(new { success = true, message = "Article removed from saved list" })
                    : BadRequest(new { success = false, message = "Failed to remove article" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, error = "Error: " + ex.Message });
            }
        }


        // Keep old endpoints for backward compatibility
        [HttpGet("latest")]
        public IActionResult GetLatestNews()
        {
            try
            {
                // This could return recent saved articles across all users
                // or redirect to a different implementation
                return Ok(new List<News>());
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Error: " + ex.Message);
            }
        }

        [HttpGet("{id}")]
        public IActionResult GetNewsById(int id, [FromQuery] int userId)
        {
            try
            {
                var item = News.GetSavedNewsById(id, userId);
                return item == null ? NotFound() : Ok(item);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Error: " + ex.Message);
            }
        }

    }

    // DTO for the save request
    public class SaveNewsRequest
    {
        public string? Title { get; set; }
        public string? Content { get; set; }
        public string? Url { get; set; }
        public string? UrlToImage { get; set; }
        public DateTime? PublishedAt { get; set; }
        public string? Source { get; set; }
        public string? Author { get; set; }
        public string? Category { get; set; }
        public string? Sentiment { get; set; }
        public string? Country { get; set; }
    }
}